<!--------- footer Section Start--------------->
<section class="footer">
  <div class="container">
    <div class="row">
      <div class="col col-lg-5 col-md-8 col-sm-8 col-12">
        <div class="row">
          <div class="d-sm-block d-flex flex-column align-items-center col-lg-7 col-md-6 col-sm-6 col-6">
            <h1><?php echo site_phrase('useful_links'); ?></h1>
            <ul>
              <?php if (get_settings('allow_instructor') == 1) : ?>
                <li> <a href="<?php echo site_url('home/become_an_instructor'); ?>"><?php echo site_phrase('Become an instructor'); ?></a></li>
              <?php endif; ?>
              <li> <a href="<?php echo site_url('blog'); ?>"><?php echo site_phrase('blog'); ?></a></li> 
              <li> <a href="<?php echo site_url('home/faq'); ?>"><?php echo site_phrase('common-questions'); ?></a></li> 
              <li><a href="<?php echo site_url('home/courses'); ?>"><?php echo site_phrase('all_courses'); ?></a></li>
              <li><a href="<?php echo site_url('sign_up'); ?>"><?php echo site_phrase('sign_up'); ?></a></li>
              <?php $custom_page_menus = $this->crud_model->get_custom_pages('', 'footer'); ?>
              <?php foreach ($custom_page_menus->result_array() as $custom_page_menu) : ?>
                <li><a href="<?php echo site_url('page/' . $custom_page_menu['page_url']); ?>"><?php echo $custom_page_menu['button_title']; ?></a></li>
              <?php endforeach; ?>
            </ul>
          </div>
          <div class="d-sm-block d-flex flex-column align-items-center col-lg-5 col-md-6 col-sm-6 col-6">
            <h1><?php echo site_phrase('help'); ?></h1>
            <ul>
              <li><a href="<?php echo site_url('home/contact_us'); ?>"><?php echo site_phrase('contact_us'); ?></a></li>
              <li><a href="<?php echo site_url('home/about_us'); ?>"><?php echo site_phrase('about_us'); ?></a></li>
              <li><a href="<?php echo site_url('home/privacy_policy'); ?>"><?php echo site_phrase('privacy_policy'); ?></a></li>
              <li><a href="<?php echo site_url('home/terms_and_condition'); ?>"><?php echo site_phrase('terms_and_condition'); ?></a></li>
              <li><a href="<?php echo site_url('home/faq'); ?>"><?php echo site_phrase('FAQ'); ?></a></li>
              <li><a href="<?php echo site_url('home/refund_policy'); ?>"><?php echo site_phrase('refund_policy'); ?></a></li>
            </ul>
          </div>
        </div>
        <div class="col-12 mt-3 lattest-news">
          <h1><?php echo get_phrase('Subscribe to our Newsletter'); ?></h1>
          <form class="ajaxForm resetable" action="<?php echo site_url('home/subscribe_to_our_newsletter'); ?>" method="post">
            <input type="email" class="form-control" id="subscribe_email" placeholder="<?php echo get_phrase('Enter your email address'); ?>" name="email">
            <button class="form-arrow" type="submit"><i class="fa-solid fa-arrow-right-long"></i></button>
          </form>
        </div>
      </div>

      <div class="col-lg-7 col-md-12 col-sm-12 col-12 d-flex flex-column align-items-center">
        <p class="text-white fs-5 px-0 text-center"><?php echo get_phrase('footer_download_app'); ?></p>
        <div class="button-list mb-0 mt-2">
          <a href="https://play.google.com/store/apps?hl=en&gl=US&pli=1"><img src="<?php echo base_url('assets/frontend/default-new/image/google-play.png') ?>" alt="" srcset="" width="120"></a>
          <a href="https://www.apple.com/jo/app-store/"><img src="<?php echo base_url('assets/frontend/default-new/image/app-store.png') ?>" alt="" srcset="" width="120"></a>
        </div>
        <p class="text-white fs-5 px-0 mb-md-0 mb-3 text-center"><?php echo get_phrase('footer_our_social'); ?></p>
        <ul class="d-flex mb-4">
          <li>
            <i class="fa-brands fa-facebook-f text-white fs-4 mx-3"></i>
          </li>
          <li>
            <i class="fa-brands fa-twitter text-white fs-4 mx-3"></i>
          </li>
          <li>
            <i class="fa-brands fa-instagram text-white fs-4 mx-3"></i>
          </li>
          <li>
            <i class="fa-brands fa-youtube text-white fs-4 mx-3"></i>
          </li>
          <li>
            <i class="fa-brands fa-whatsapp text-white fs-4 mx-3"></i>
          </li>
        </ul>
        <img loading="lazy" src="<?php echo base_url('uploads/system/' . get_frontend_settings('light_logo')); ?>">
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <ul class="nav justify-content-center">
          <li class="nav-item m-0 mb-3">
            <a class="fs-5" target="_blank" href="<?php echo get_settings('footer_link'); ?>">
              <?php echo site_phrase(get_settings('footer_text')); ?>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</section>
<!--------- footer Section End--------------->

<!-- PAYMENT MODAL -->
<!-- Modal -->
<?php
$paypal_info = json_decode(get_settings('paypal'), true);
$stripe_info = json_decode(get_settings('stripe_keys'), true);
if ($paypal_info[0]['active'] == 0) {
  $paypal_status = 'disabled';
} else {
  $paypal_status = '';
}
if ($stripe_info[0]['active'] == 0) {
  $stripe_status = 'disabled';
} else {
  $stripe_status = '';
}
?>