<section class="content py-5 px-3">
    <div class="row">
        <div class="header d-flex flex-column align-items-center">
            <h1 class="fs-1 mb-4 text-center"><?php echo get_phrase('academic_school_title'); ?></h1>
            <p class="fs-4 text-center"><?php echo get_phrase('academic_school_p'); ?></p>
        </div>
        <div class="container mt-5 custom-nav">
            <ul class="nav nav-tabs d-flex justify-content-evenly align-items-center mb-5" id="myTab" role="tablist">
                <li class="nav-item position-relative" role="presentation">
                    <button class="nav-link active" id="stage1-tab" data-bs-target="#stage1" type="button" role="tab" aria-controls="stage1" aria-selected="true">1</button>
                    <span class="position-absolute"><?php echo get_phrase('class'); ?></span>
                </li>
                <li class="tab-line mx-2 active" id="tab-line-1"></li>
                <li class="nav-item position-relative" role="presentation">
                    <button class="nav-link" id="stage2-tab" data-bs-target="#stage2" type="button" role="tab" aria-controls="stage2" aria-selected="false">2</button>
                    <span class="position-absolute text-center"><?php echo get_phrase('semester'); ?></span>
                </li>
                <li class="tab-line mx-2" id="tab-line-2"></li>
                <li class="nav-item position-relative" role="presentation">
                    <button class="nav-link" id="stage3-tab" data-bs-target="#stage3" type="button" role="tab" aria-controls="stage3" aria-selected="false">3</button>
                    <span class="position-absolute"><?php echo get_phrase('material'); ?></span>
                </li>
            </ul>
            <div class="tab-content py-5" id="myTabContent">
                <div class="tab-pane fade show active" id="stage1" role="tabpanel" aria-labelledby="stage1-tab">
                    <p class="text-center fs-4 mb-4"><?php echo get_phrase('choose_class'); ?></p>
                    <div class="categories row">
                        <?php
                        $categories = $this->crud_model->get_categories()->result_array();
                        if (count($categories) > 0) :
                            foreach ($categories as $key => $category) :
                        ?>
                                <div class="item-container col-lg-3 col-6 px-2 mb-2">
                                    <div class="cat-item rounded-2 p-3" data-id="<?php echo $category['id']; ?>" role="button">
                                        <?php echo preg_match('/^{{.*}}$/', $category['name'], $string) ? get_phrase(trim(substr($category['name'], 2, -2))) : $category['name']; ?>
                                    </div>
                                </div>
                            <?php
                            endforeach;
                        else :
                            ?>
                            <div class="text-center">
                                <?php echo get_phrase('no_data_found'); ?>
                            </div>
                        <?php
                        endif;
                        ?>
                    </div>
                </div>
                <div class="tab-pane fade" id="stage2" role="tabpanel" aria-labelledby="stage2-tab">
                    <button id="back_to_categories_tab" class="btn btn-secondary my-0 border-0" style="background-color: #3583f9;"><?php echo get_phrase('back'); ?></button>
                    <p class="text-center fs-4 mb-4"><?php echo get_phrase('choose_semester'); ?></p>
                    <div id="stage2-loader" class="spinner-border text-primary mx-auto" role="status" style="display: block;">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <div class="sub_categories row">
                    </div>
                </div>
                <div class="tab-pane fade" id="stage3" role="tabpanel" aria-labelledby="stage3-tab">
                    <button id="back_to_subcategories_tab" class="btn btn-secondary my-0 border-0" style="background-color: #3583f9;"><?php echo get_phrase('back'); ?></button>
                    <p class="text-center fs-4 mb-4"><?php echo get_phrase('choose_material'); ?></p>
                    <div id="stage3-loader" class="spinner-border text-primary mx-auto" role="status" style="display: block;">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <div class="lessons row">
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>

<script>
    $(document).ready(function() {
        $(".cat-item").click(function() {
            // Get data from some input field, for example
            var id = $(this).attr("data-id");
            $(".sub_categories").hide()
            $("#stage2-loader").show()
            tab_navigator("#stage2-tab")
            $.ajax({
                url: "<?php echo base_url('school/get_sub_categories'); ?>",
                type: "POST",
                data: {
                    id
                }, // Send data to the server
                success: function(response) {
                    $(".sub_categories").html(response);
                    $(".sub_categories").show()
                    $("#stage2-loader").hide()
                }
            });
        });
    });

    $("#back_to_categories_tab").click(function() {
        tab_navigator("#stage1-tab")
    })
    $("#back_to_subcategories_tab").click(function() {
        tab_navigator("#stage2-tab")
    })
</script>