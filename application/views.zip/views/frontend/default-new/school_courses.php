<?php
if (count($courses) > 0) :
    foreach ($courses as $key => $course) :
?>
        <div class="item-container col-lg-3 col-6 px-2 mb-2">
            <a class="d-block" href="<?php echo site_url('home/course/' . rawurlencode(slugify($course->title)) . '/' . $course->id); ?>">
                <div class="subcat-item rounded-2 p-3" role="button">
                    <?php echo $course->title; ?>
                </div>
            </a>
        </div>
    <?php
    endforeach;
else :
    ?>
    <div class="text-center">
        No Data Found
    </div>
<?php
endif;
?>