<!---------- Header Section start  ---------->
<?php $cart_items = $this->session->userdata('cart_items'); ?>
<?php $user_id = $this->session->userdata('user_id'); ?>
<?php $user_login = $this->session->userdata('user_login'); ?>
<?php $admin_login = $this->session->userdata('admin_login'); ?>
<?php if ($user_id > 0) {
  $user_details = $this->user_model->get_all_user($user_id)->row_array();
} ?>

<!---------- Header Section End  ---------->

<nav class="navbar navbar-expand-lg navbar-custom py-2">
  <div class="container-fluid py-2 px-5">
    <a href="<?php echo site_url(); ?>">
      <img src="<?php echo site_url('uploads/system/' . get_frontend_settings('dark_logo')) ?>" alt="" srcset="" height="40px">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div id="navbarNav" class="collapse navbar-collapse">
      <div class="justify-content-start">
        <ul class="navbar-nav">
          <ul class="navbar-nav main-nav-wrap mb-lg-0 align-items-center d-block">
            <li class="nav-item">
              <a class="nav-link text-nowrap" href="<?php echo site_url('/home/courses'); ?>" id="navbarDropdown1">
                <span><?php echo get_phrase("Header-courses"); ?></span>
              </a>
              <ul class="navbarHover">
                <?php
                $categories = $this->crud_model->get_categories()->result_array();
                foreach ($categories as $key => $category) : ?>
                  <li class="dropdown-submenu">
                    <a href="<?php echo site_url('home/courses?category=' . slugify($category['slug'])) ?>">
                      <span class="icons"><i class="<?php echo $category['font_awesome_class']; ?>"></i></span>
                      <span class="text-cat"><?php echo preg_match('/^{{.*}}$/', $category['name'], $string) ? get_phrase(trim(substr($category['name'], 2, -2))) : $category['name']; ?></span>
                      <span class="has-sub-category ms-auto"><i class="fa-solid fa-angle-right"></i></span>
                    </a>
                    <ul class="sub-category-menu">
                      <?php
                      $sub_categories = $this->crud_model->get_sub_categories($category['id']);
                      foreach ($sub_categories as $sub_category) : ?>
                        <li><a href="<?php echo site_url('home/courses?category=' . slugify($sub_category['slug'])) ?>"><?php echo preg_match('/^{{.*}}$/', $sub_category['name'], $string) ? get_phrase(trim(substr($sub_category['name'], 2, -2))) : $sub_category['name']; ?></a></li>
                      <?php endforeach; ?>
                    </ul>
                  </li>
                <?php endforeach; ?>
                <li>
                  <a href="<?php echo site_url('home/courses'); ?>">
                    <i class="fas fa-list-ul px-2"></i>
                    <?php echo get_phrase('All Courses'); ?>
                  </a>
                </li>
              </ul>
            </li>
          </ul>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo site_url('school'); ?>"><?php echo get_phrase('school'); ?></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo site_url('course_bundles'); ?>"><?php echo get_phrase('study-packages'); ?></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo site_url('tutors'); ?>"><?php echo get_phrase('book-lesson'); ?></a>
          </li>
          <li class="nav-item d-flex justiy-content-center align-items-center" style="background-color: #ffaa51;
                border-radius: 30px;
                padding: 0px 10px;">
            <a class="nav-link special-link text-center" href="<?php echo site_url('home/contact_us'); ?>"><?php echo get_phrase('contact-us'); ?></a>
          </li>
        </ul>
      </div>
      <div class="ms-auto">
        <ul class="navbar-nav">
          <?php if ($user_login) : ?>
            <li class="nav-item d-flex justify-content-center align-items-center"><a class="dropdown-item text-center" href="<?php echo site_url('home/my_courses') ?>"><?php echo site_phrase('My Course') ?></a></li>
          <?php elseif ($admin_login) : ?>
            <li class="nav-item d-flex justify-content-center align-items-center"><a class="dropdown-item text-center" href="<?php echo site_url('admin'); ?>"><?php echo get_phrase('Administration') ?></a></li>
          <?php endif; ?>

          <!-- Shopping Cart -->
          <li class="nav-item d-flex justify-content-center align-items-center">
            <!-- Cart List Area -->
            <div class="wisth_tgl_div">
              <div class="wisth_tgl_2div">
                <a class="menu_pro_cart_tgl mt-1 text-dark fs-6"><i class="fa-solid fa-cart-shopping"></i>
                  <p class="menu_number position-absolute text-white d-flex justify-content-center align-items-center" id="cartItemsCounter" style="top: 0px;left: -5px;background: #f6a44e;border-radius: 50%;font-size: 12px;width: 14px;height: 14px;padding-top: 3px;"><?php echo count($cart_items); ?></p>
                </a>
                <div class="menu_pro_wish">
                  <div class="overflow-control" id="cartItems">

                    <?php include "cart_items.php"; ?>

                  </div>
                  <div class="menu_pro_btn">
                    <a href="<?php echo site_url('home/shopping_cart'); ?>" type="submit" class="btn btn-primary text-dark fw-bold" style="background: #ffac51;"><?php echo get_phrase('Checkout'); ?></a>
                  </div>
                </div>
              </div>
            </div>
          </li>

          <?php if ($user_login) : ?>
            <li class="nav-item d-flex justify-content-center align-items-center">
              <!-- Wish List Area -->
              <div class="wisth_tgl_div">
                <div class="wisth_tgl_2div">
                  <a class="menu_wisth_tgl mt-1 text-dark fs-6 mx-1">
                    <i class="fa-regular fa-heart"></i>

                    <?php if (count($my_wishlist_items) > 0) : ?>
                      <p class="menu_number" id="wishlistItemsCounter">
                        <?php echo count($my_wishlist_items); ?>
                      </p>
                    <?php endif; ?>
                  </a>
                  <div class="menu_pro_wish">
                    <div class="overflow-control" id="wishlistItems">
                      <?php include "wishlist_items.php"; ?>
                    </div>
                    <div class="menu_pro_btn">
                      <a href="<?php echo site_url('home/my_wishlist'); ?>" class="btn btn-primary text-dark fw-bold" style="background: #ffac51;"><?php echo get_phrase('Go to wishlist'); ?></a>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Notification Area -->
              <div class="wisth_tgl_div">
                <div class="wisth_tgl_2div" id="headerNotification">
                  <?php include "notifications.php"; ?>
                </div>
              </div>
            </li>
          <?php endif; ?>

          <!-- Login/Register links -->
          <?php if (!$user_id) : ?>
            <li class="nav-item d-flex justify-content-center align-items-center">
              <a class="text-dark fs-6" href="<?php echo site_url('login'); ?>"> <?php echo get_phrase('Login'); ?></a>
            </li>
            <li class="nav-item d-flex justify-content-center align-items-center">
              <a class="text-dark fs-6" href="<?php echo site_url('sign_up'); ?>" class="text-capitalize" style="min-width: 70px"> <?php echo get_phrase('Join Now'); ?></a>
            </li>
          <?php endif; ?>

          <?php if ($user_login || $admin_login) : ?>
            <!-- Profile Area -->
            <div class="menu_pro_tgl_div d-flex justify-content-center">
              <div class="menu_pro_tgl-2div">
                <a class="menu_pro_tgl profile-dropdown"><img loading="lazy" src="<?php echo $this->user_model->get_user_image_url($user_id); ?>" alt="User Image" /></a>
              </div>
              <div class="menu_pro_tgl_bg">
                <div class="path-pos d-flex flex-column">
                  <a href="#"><img loading="lazy" src="<?php echo $this->user_model->get_user_image_url($user_id); ?>" alt="User Image" /></a>
                  <a href="#">
                    <h4><?php echo $user_details['first_name'] . ' ' . $user_details['last_name']; ?></h4>
                  </a>
                  <p><?php echo $user_details['email']; ?></p>
                  <ul>
                    <?php if ($user_login) : ?>

                      <?php if ($user_details['is_instructor'] == 1) : ?>
                        <li class="user-dropdown-menu-item"><a href="<?php echo site_url('user/dashboard'); ?>"><i class="fas fa-columns"></i><?php echo site_phrase('Instructor Dashboard'); ?></a></li>
                      <?php else : ?>
                        <?php if (get_settings('allow_instructor') == 1) : ?>
                          <li class="user-dropdown-menu-item"><a href="<?php echo site_url('home/become_an_instructor'); ?>"><i class="fas fa-columns"></i><?php echo site_phrase('Become an instructor'); ?></a></li>
                        <?php endif; ?>
                      <?php endif; ?>

                      <li class="user-dropdown-menu-item"><a href="<?php echo site_url('home/my_courses'); ?>"><i class="far fa-gem"></i><?php echo site_phrase('my_courses'); ?></a></li>
                      <li class="user-dropdown-menu-item"><a href="<?php echo site_url('home/my_wishlist'); ?>"><i class="far fa-heart"></i><?php echo site_phrase('my_wishlist'); ?></a></li>
                      <li class="user-dropdown-menu-item"><a href="<?php echo site_url('home/my_messages'); ?>"><i class="far fa-envelope"></i><?php echo site_phrase('my_messages'); ?></a></li>
                      <li class="user-dropdown-menu-item"><a href="<?php echo site_url('home/purchase_history'); ?>"><i class="fas fa-shopping-cart"></i><?php echo site_phrase('purchase_history'); ?></a></li>
                      <li class="user-dropdown-menu-item"><a href="<?php echo site_url('home/profile/user_profile'); ?>"><i class="fas fa-user"></i><?php echo site_phrase('user_profile'); ?></a></li>
                      <?php if (addon_status('affiliate_course')) :
                        $CI    = &get_instance();
                        $CI->load->model('addons/affiliate_course_model');
                        $x = $CI->affiliate_course_model->is_affilator($this->session->userdata('user_id'));
                        $is_affiliator = $CI->affiliate_course_model->is_affilator($this->session->userdata('user_id'));

                        if ($x == 0 && get_settings('affiliate_addon_active_status') == 1) : ?>


                          <li class="user-dropdown-menu-item"><a href="<?php echo site_url('addons/affiliate_course/become_an_affiliator'); ?>"><i class="fas fa-user-plus"></i><?php echo site_phrase('Become_an_Affiliator'); ?></a></li>
                        <?php else : ?>
                          <?php if ($is_affiliator == 1) : ?>


                            <li class="user-dropdown-menu-item"><a href="<?php echo site_url('addons/affiliate_course/affiliate_course_history '); ?>"><i class="fa fa-book"></i><?php echo site_phrase('Affiliation History'); ?></a></li>
                          <?php endif; ?>
                        <?php endif; ?>
                      <?php endif; ?>
                      <?php if (addon_status('customer_support')) : ?>
                        <li class="user-dropdown-menu-item"><a href="<?php echo site_url('addons/customer_support/user_tickets'); ?>"><i class="fas fa-life-ring"></i><?php echo site_phrase('support'); ?></a></li>
                      <?php endif; ?>
                    <?php endif; ?>

                    <?php if ($admin_login) : ?>
                      <li>
                        <a href="<?php echo site_url('admin'); ?>">
                          <i class="fas fa-location-arrow"></i>
                          <?php echo get_phrase('Administration'); ?>
                        </a>
                      </li>
                      <li>
                        <a href="<?php echo site_url('admin/manage_profile'); ?>">
                          <i class="fas fa-user"></i>
                          <?php echo get_phrase('Manage profile') ?>
                        </a>
                      </li>
                      <li>
                        <a href="<?php echo site_url('admin/system_settings'); ?>">
                          <i class="fas fa-cog"></i>
                          <?php echo get_phrase('Settings') ?>
                        </a>
                      </li>
                    <?php endif; ?>

                    <li>
                      <a href="<?php echo site_url('login/logout'); ?>">
                        <i class="fa-solid fa-arrow-right-from-bracket"></i>
                        <?php echo get_phrase('Log out'); ?>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          <?php endif; ?>

          <!-- Change Language -->
          <li class="nav-item d-flex justify-content-center align-items-center">
            <form action="#" method="POST" class="language-control select-box">
              <select onchange="actionTo(`<?php echo site_url('home/switch_language/') ?>${$(this).val()}`)" class="border-0 nice-select w-auto px-0 fw-bold" style="background-color: transparent !important;">
                <?php
                $languages = $this->crud_model->get_all_languages();
                $selected_language = $this->session->userdata('language');
                foreach ($languages as $language) : ?>
                  <?php if (trim($language) != "") : ?>
                    <option value="<?php echo strtolower($language); ?>" <?php if ($selected_language == $language) : ?>selected<?php endif; ?>><?php echo ucwords($language); ?></option>
                  <?php endif; ?>
                <?php endforeach; ?>
              </select>
            </form>
          </li>
        </ul>
      </div>
    </div>
  </div>
</nav>