<section id="courses-header" class="text-center py-5">
    <div class="container py-4">
        <h1 class="text-dark fs-2 fw-bold mb-4"><?php echo get_phrase('bundle_header_title'); ?></h1>
        <p class="text-dark fs-4 mb-3"><?php echo get_phrase('bundle_header_p1'); ?></p>
        <p class="fs-5 mb-3"><?php echo get_phrase('bundle_header_p2'); ?></p>
    </div>
</section>