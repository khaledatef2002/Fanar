<?php $total = $bundle_details['price']; ?>
<?php if (isset($coupon_code) && !empty($coupon_code)) : ?>
    <?php if($this->crud_model->check_coupon_validity($coupon_code)): ?>
        <?php $coupon_details = $this->crud_model->get_coupon_details_by_code($coupon_code)->row_array(); ?>
        <?php $coupon_discounted_price = ($total * $coupon_details['discount_percentage']) / 100; ?>

        <div class="alert alert-success text-13px text-center py-2 d-block" role="alert">
            <?php echo get_phrase('You received').' '.currency($coupon_discounted_price).' ('.$coupon_details['discount_percentage']; ?>%) <?php echo site_phrase('coupon discount'); ?>
        </div>
        <?php
            $total = $total - $coupon_discounted_price;
            $total = ($total > 0) ? $total : 0;
            $this->session->set_userdata('bundle_applied_coupon', $coupon_code);
        ?>
    <?php else: ?>
        <div class="alert alert-danger text-13px text-center py-2 d-block" role="alert">
            <?php echo get_phrase('Your coupon code has expired'); ?>
            <?php $this->session->set_userdata('bundle_applied_coupon', null); ?>
        </div>
    <?php endif; ?>
<?php else: ?>
    <?php $this->session->set_userdata('applied_coupon', null); ?>
<?php endif; ?>
<h1 class="fw-500 m-0 p-0 d-flex align-items-center"><?php echo currency($total); ?> <?php if(isset($coupon_discounted_price) && !empty($coupon_discounted_price)) { ?><p class="fw-300 m-0 ms-2 p-0 fs-4 text-decoration-line-through text-danger"><?php echo $bundle_details['price']; ?></p><?php } ?></h1>